@extends('site.layout')
@section('title', $page->title.' · MyBaap')
@section('content')
    <article class="page">
        <h1>{{ $page->title }}</h1>
        <div>{!! $page->content !!}</div>
    </article>
@endsection
