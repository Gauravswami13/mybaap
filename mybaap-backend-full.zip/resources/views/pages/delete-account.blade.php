@extends('site.layout')
@section('title', 'Delete account · MyBaap')
@section('content')
    <article class="page">
        <h1>Delete your MyBaap account</h1>
        <p>Open the MyBaap Android app and sign in with your mobile number.</p>
        <ol>
            <li>Open Profile from the home screen.</li>
            <li>Tap Delete Account at the bottom.</li>
            <li>Confirm. This removes your name and mobile number and ends an active subscription.</li>
        </ol>
        <p>You can register again later with the same mobile number. Subscription payment records stay on the server without your name or mobile number.</p>
    </article>
@endsection
