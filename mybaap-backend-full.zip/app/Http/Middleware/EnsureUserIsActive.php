<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsActive
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if ($user !== null && method_exists($user, 'isBlocked') && $user->isBlocked()) {
            return response()->json([
                'success' => false,
                'message' => 'Your account is blocked.',
                'data' => (object) [],
            ], 403);
        }

        return $next($request);
    }
}
