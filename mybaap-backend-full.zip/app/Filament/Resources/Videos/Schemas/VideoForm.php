<?php

namespace App\Filament\Resources\Videos\Schemas;

use App\Filament\Resources\Videos\Pages\CreateVideo;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;

class VideoForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Video details')
                    ->description('Title, category, and description show on the app home and video page.')
                    ->columns(2)
                    ->schema([
                        Select::make('category_id')
                            ->label('Category')
                            ->relationship('category', 'name')
                            ->searchable()
                            ->preload()
                            ->required(),
                        TextInput::make('title')
                            ->required()
                            ->maxLength(255),
                        Textarea::make('description')
                            ->rows(4)
                            ->columnSpanFull(),
                        TextInput::make('duration_seconds')
                            ->label('Duration (seconds)')
                            ->numeric()
                            ->minValue(0)
                            ->helperText('Example: 90 is 1 minute 30 seconds. Shown on the video page.'),
                        TextInput::make('sort_order')
                            ->numeric()
                            ->default(0)
                            ->required()
                            ->helperText('Lower numbers appear first.'),
                    ]),
                Section::make('Poster and video file')
                    ->description('The poster is public. The video file stays private and is never returned by the API.')
                    ->columns(2)
                    ->schema([
                        FileUpload::make('thumbnail')
                            ->label('Poster')
                            ->disk('public')
                            ->directory('thumbnails')
                            ->image()
                            ->imageEditor()
                            ->maxSize(4096)
                            ->helperText('JPG or PNG, up to 4 MB. Used on home, search, and the video page.'),
                        FileUpload::make('playback_path')
                            ->label('Video file')
                            ->disk('local')
                            ->directory('videos')
                            ->visibility('private')
                            ->acceptedFileTypes(['video/mp4', 'video/webm', 'video/quicktime'])
                            ->previewable(false)
                            ->openable(false)
                            ->downloadable(false)
                            ->required(fn ($livewire): bool => $livewire instanceof CreateVideo)
                            ->helperText('MP4, WebM, or MOV. Playback opens only after login, and paid videos also need an active plan.'),
                    ]),
                Section::make('Who can watch')
                    ->columns(2)
                    ->schema([
                        Toggle::make('is_paid')
                            ->label('Paid video')
                            ->default(true)
                            ->helperText('On: locked until the user has an active subscription. Off: anyone logged in can watch.'),
                        Toggle::make('is_active')
                            ->label('Show in the app')
                            ->default(true)
                            ->helperText('Off hides this video from home, search, and categories.'),
                    ]),
            ]);
    }
}
