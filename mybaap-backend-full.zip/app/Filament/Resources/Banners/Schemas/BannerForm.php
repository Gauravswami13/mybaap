<?php

namespace App\Filament\Resources\Banners\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class BannerForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('title')
                    ->required()
                    ->maxLength(255),
                FileUpload::make('image')
                    ->disk('public')
                    ->directory('banners')
                    ->image()
                    ->required()
                    ->helperText('Wide image for the home hero. Play Now uses the first video.'),
                TextInput::make('link')
                    ->url()
                    ->maxLength(255)
                    ->helperText('Optional. Leave empty for a normal home banner.'),
                TextInput::make('sort_order')
                    ->numeric()
                    ->default(0)
                    ->required(),
                Toggle::make('is_active')
                    ->default(true),
            ]);
    }
}
