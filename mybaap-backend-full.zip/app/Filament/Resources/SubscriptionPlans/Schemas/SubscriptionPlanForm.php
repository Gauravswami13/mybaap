<?php

namespace App\Filament\Resources\SubscriptionPlans\Schemas;

use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;

class SubscriptionPlanForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Plan')
                    ->description('Active plans appear on the app Plans tab. Price is in rupees.')
                    ->columns(2)
                    ->schema([
                        TextInput::make('name')
                            ->required()
                            ->maxLength(80),
                        TextInput::make('price')
                            ->required()
                            ->numeric()
                            ->prefix('₹')
                            ->helperText('Amount the app charges with Razorpay.'),
                        TextInput::make('duration_days')
                            ->label('Length (days)')
                            ->required()
                            ->numeric()
                            ->minValue(1)
                            ->helperText('Example: 30 for one month. Used when you assign this plan by hand.'),
                        TextInput::make('sort_order')
                            ->required()
                            ->numeric()
                            ->default(0),
                        Textarea::make('description')
                            ->rows(3)
                            ->columnSpanFull()
                            ->helperText('Shown under the plan name in the app.'),
                        Toggle::make('is_active')
                            ->label('Show in the app')
                            ->default(true)
                            ->required(),
                    ]),
            ]);
    }
}
