<?php

namespace App\Filament\Resources\UserSubscriptions\Schemas;

use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\UserSubscription;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Schema;
use Illuminate\Support\Carbon;

class UserSubscriptionForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Give a user a plan')
                    ->description('Use this when payment is taken outside the app. The end date fills from the plan length.')
                    ->columns(2)
                    ->schema([
                        Select::make('user_id')
                            ->label('User')
                            ->relationship('user', 'mobile')
                            ->getOptionLabelFromRecordUsing(fn (User $record): string => trim(($record->name ?: 'User').' · '.$record->mobile))
                            ->searchable()
                            ->preload()
                            ->required(),
                        Select::make('plan_id')
                            ->label('Plan')
                            ->relationship('plan', 'name')
                            ->searchable()
                            ->preload()
                            ->live()
                            ->afterStateUpdated(fn (Get $get, Set $set) => self::fillEndDate($get, $set))
                            ->required(),
                        DatePicker::make('start_date')
                            ->required()
                            ->default(now()->toDateString())
                            ->live()
                            ->afterStateUpdated(fn (Get $get, Set $set) => self::fillEndDate($get, $set)),
                        DatePicker::make('end_date')
                            ->required()
                            ->helperText('Filled when you pick a plan. You can still change it.'),
                        Select::make('status')
                            ->options([
                                UserSubscription::STATUS_ACTIVE => 'Active',
                                UserSubscription::STATUS_EXPIRED => 'Expired',
                                UserSubscription::STATUS_CANCELLED => 'Cancelled',
                            ])
                            ->default(UserSubscription::STATUS_ACTIVE)
                            ->required()
                            ->helperText('Only Active, and an end date that is today or later, unlocks paid videos.'),
                        TextInput::make('payment_ref')
                            ->label('Payment reference')
                            ->maxLength(120)
                            ->helperText('Optional. Razorpay payment id, or a note such as cash.'),
                    ]),
            ]);
    }

    private static function fillEndDate(Get $get, Set $set): void
    {
        $planId = $get('plan_id');
        $start = $get('start_date');
        if (! $planId || ! $start) {
            return;
        }

        $days = SubscriptionPlan::query()->whereKey($planId)->value('duration_days');
        if (! $days) {
            return;
        }

        $set('end_date', Carbon::parse($start)->addDays((int) $days)->toDateString());
    }
}
