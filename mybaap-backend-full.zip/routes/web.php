<?php

use App\Http\Controllers\PageController;
use App\Http\Controllers\Web\AccountController;
use App\Http\Controllers\Web\AuthController;
use App\Http\Controllers\Web\SiteController;
use Illuminate\Support\Facades\Route;

Route::get('/', [SiteController::class, 'home'])->name('home');
Route::get('/category/{id}', [SiteController::class, 'category'])->whereNumber('id');
Route::get('/videos/{id}', [SiteController::class, 'video'])->whereNumber('id');
Route::get('/plans', [SiteController::class, 'plans'])->name('plans');
Route::get('/faq', [AccountController::class, 'faq'])->name('faq');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'show'])->name('login');
    Route::post('/login', [AuthController::class, 'send'])->middleware('throttle:send-otp');
    Route::get('/login/otp', [AuthController::class, 'otp'])->name('login.otp');
    Route::post('/login/otp', [AuthController::class, 'verify'])->middleware('throttle:verify-otp');
});

Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/account', [AccountController::class, 'show'])->name('account');
    Route::get('/account/edit', [AccountController::class, 'edit'])->name('profile.edit');
    Route::post('/account', [AccountController::class, 'update']);
    Route::post('/account/delete', [AccountController::class, 'destroy'])->name('account.delete');
    Route::get('/history', [AccountController::class, 'history'])->name('history');
    Route::get('/notifications', [AccountController::class, 'notifications'])->name('notifications');
    Route::get('/watch/{id}', [AccountController::class, 'watch'])->whereNumber('id')->name('watch');
    Route::post('/plans/{plan}/pay', [AccountController::class, 'checkout'])->name('plans.pay');
    Route::post('/plans/{plan}/verify', [AccountController::class, 'verifyPayment'])->name('plans.verify');
});

Route::get('/privacy-policy', [PageController::class, 'show'])->defaults('slug', 'privacy-policy');
Route::get('/terms', [PageController::class, 'show'])->defaults('slug', 'terms');
Route::view('/delete-account', 'pages.delete-account');
