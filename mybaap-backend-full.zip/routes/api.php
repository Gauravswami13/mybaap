<?php

use App\Http\Controllers\Api\AccountController;
use App\Http\Controllers\Api\AppController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CatalogController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\ContentController;
use App\Http\Controllers\Api\PaymentWebhookController;
use App\Http\Controllers\Api\PlaybackController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\RazorpayController;
use App\Http\Controllers\Api\SettingsController;
use App\Http\Controllers\Api\SubscriptionController;
use Illuminate\Support\Facades\Route;

Route::get('/settings/public', [SettingsController::class, 'show']);
Route::get('/app/bootstrap', [AppController::class, 'bootstrap']);
Route::get('/pages/{slug}', [ContentController::class, 'page'])->where('slug', '[a-z0-9\-]+');
Route::get('/faqs', [ContentController::class, 'faqs']);

Route::post('/auth/send-otp', [AuthController::class, 'sendOtp'])->middleware('throttle:send-otp');
Route::post('/auth/verify-otp', [AuthController::class, 'verifyOtp'])->middleware('throttle:verify-otp');
Route::post('/payments/webhook', [PaymentWebhookController::class, 'handle'])->middleware('throttle:30,1');
Route::get('/media/videos/{id}', [PlaybackController::class, 'stream'])
    ->middleware('signed')
    ->whereNumber('id')
    ->name('videos.stream');

Route::delete('/account', [AccountController::class, 'destroy'])->middleware('auth:sanctum');

Route::middleware(['auth:sanctum', 'active'])->group(function () {
    Route::post('/auth/logout', [AuthController::class, 'logout']);
    Route::get('/profile', [ProfileController::class, 'show']);
    Route::match(['put', 'post'], '/profile', [ProfileController::class, 'update']);
    Route::post('/payments/razorpay/order', [RazorpayController::class, 'order']);
    Route::post('/payments/razorpay/verify', [RazorpayController::class, 'verify']);
    Route::get('/notifications', [NotificationController::class, 'index']);

    Route::get('/home', [CatalogController::class, 'home']);
    Route::get('/categories', [CatalogController::class, 'categories']);
    Route::get('/videos', [CatalogController::class, 'videos']);
    Route::get('/videos/{id}/playback', [PlaybackController::class, 'show'])->whereNumber('id');
    Route::get('/videos/{id}', [CatalogController::class, 'show'])->whereNumber('id');

    Route::get('/plans', [SubscriptionController::class, 'plans']);
    Route::get('/subscription', [SubscriptionController::class, 'current']);
    Route::get('/subscription/history', [SubscriptionController::class, 'history']);
});
